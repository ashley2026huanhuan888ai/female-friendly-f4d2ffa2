import { existsSync, readdirSync, readFileSync } from "node:fs";
import path from "node:path";

const root = process.cwd();
const failures = [];

function fail(message) {
  failures.push(message);
}

function read(rel) {
  return readFileSync(path.join(root, rel), "utf8");
}

function walk(dir, files = []) {
  const abs = path.join(root, dir);
  if (!existsSync(abs)) return files;
  for (const entry of readdirSync(abs, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name === "dist" || entry.name === ".tanstack") continue;
    const rel = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(rel, files);
    else files.push(rel);
  }
  return files;
}

function requireIncludes(rel, fragments) {
  const text = read(rel);
  for (const fragment of fragments) {
    if (!text.includes(fragment)) fail(`${rel} is missing required guard fragment: ${fragment}`);
  }
}

const sourceFiles = walk("src").filter((file) => /\.(ts|tsx|js|jsx)$/.test(file));

// 1) objects.temperature and temperature_events writes must stay in the single temperature entrypoint.
for (const rel of sourceFiles) {
  const text = read(rel);
  const objectUpdateBlocks = [...text.matchAll(/from\(["']objects["']\)[\s\S]{0,220}?\.update\(([\s\S]{0,700}?)\)[\s\S]{0,180}?(?:;|\n\s*(?:const|let|await|return|if|for)\b)/g)];
  for (const match of objectUpdateBlocks) {
    if (/\btemperature\b/.test(match[1]) && rel !== "src/lib/api/temperature.functions.ts") {
      fail(`${rel} writes objects.temperature outside src/lib/api/temperature.functions.ts`);
    }
  }

  const tempEventWrites = [
    ...text.matchAll(/from\(["']temperature_events["'](?:\s+as\s+never)?\)[\s\S]{0,180}?\.(insert|update|delete|upsert)\(/g),
  ];
  if (tempEventWrites.length > 0 && rel !== "src/lib/api/temperature.functions.ts") {
    fail(`${rel} writes temperature_events outside src/lib/api/temperature.functions.ts`);
  }
}

// 2) Recompute must not be silently fire-and-forget in server mutation paths.
const platform = read("src/lib/api/platform.functions.ts");
if (/void\s+recomputeObjectInternal\s*\(/.test(platform)) {
  fail("platform.functions.ts contains fire-and-forget recomputeObjectInternal");
}
if (/recomputeObjectInternal\s*\([^)]*\)\.catch\s*\(\s*\(\s*\)\s*=>\s*\{\s*\}\s*\)/.test(platform)) {
  fail("platform.functions.ts silently swallows recomputeObjectInternal errors");
}

// 3) Legal/regulatory rule floor must remain after AI/cooling output.
requireIncludes("src/lib/api/temperature.functions.ts", [
  "aggregateRuleMinimum",
  "Math.max(aiTemperature, ruleMinimum, adminMin)",
  "observation_count: result.breakdown.active_count",
]);
requireIncludes("src/lib/temperature-rules.ts", [
  "detectLegalPenalty",
  "has_regulatory_penalty",
  "rule_minimum_temperature",
]);

// 4) Frontend object temperature displays must preserve unmeasured state for zero-observation objects.
requireIncludes("src/components/ObjectCard.tsx", [
  "unmeasured={observation_count === 0}",
  "pointer-events-auto",
  "to=\"/objects/$id\"",
]);
requireIncludes("src/routes/objects.$id.tsx", [
  "unmeasured={obj.observation_count === 0}",
]);
requireIncludes("src/routes/index.tsx", [
  "unmeasured={(o.observation_count ?? 0) === 0}",
]);
requireIncludes("src/routes/discussions.tsx", [
  "objects(id, name, type, temperature, observation_count)",
  "unmeasured={(o.objects.observation_count ?? 0) === 0}",
]);
requireIncludes("src/routes/me.tsx", [
  "unmeasured={(o.observation_count ?? 0) === 0}",
]);
requireIncludes("src/components/PreviewGate.tsx", [
  "unmeasured={(o.observation_count ?? 0) === 0}",
]);

// 5) Search-miss object requests must stay direct and user-visible.
requireIncludes("src/routes/objects.tsx", [
  "requestObjectFromSearch",
  "handleRequest(searchedKeyword)",
  "申请建立",
  "toast.success",
  "toast.info",
  "navigate({ to: \"/objects/$id\"",
]);
requireIncludes("src/lib/api/platform.functions.ts", [
  "export const requestObjectFromSearch",
  "object_exists",
  "request_exists",
  "created",
  "用户在搜索时未找到该对象，因此申请建立。",
]);

// 6) Remember-login behavior must keep the chosen product contract.
requireIncludes("src/routes/login.tsx", [
  "const [remember, setRememberState] = useState(true)",
  "setRemember(remember)",
  "保持登录 30 天",
]);
requireIncludes("src/components/AuthProvider.tsx", [
  "isRememberExpired()",
  "await supabase.auth.signOut()",
  "clearRemember()",
  "markExpiredNotice()",
]);

// 7) Legacy default-comfort helpers must not re-enter active temperature writes.
const computeTemperatureUses = sourceFiles.flatMap((rel) => {
  const text = read(rel);
  return [...text.matchAll(/\bcomputeTemperature\s*\(/g)].map((match) => ({ rel, index: match.index ?? 0 }));
});
const activeComputeTemperatureUses = computeTemperatureUses.filter(({ rel, index }) => {
  if (rel !== "src/lib/temperature.ts") return true;
  const prefix = read(rel).slice(Math.max(0, index - 32), index);
  return !/function\s+$/.test(prefix);
});
if (activeComputeTemperatureUses.length > 0) {
  fail(`legacy computeTemperature is used: ${activeComputeTemperatureUses.map((u) => u.rel).join(", ")}`);
}
for (const rel of sourceFiles) {
  const text = read(rel);
  if (rel !== "src/lib/temperature.ts" && /\btemperature\s*:\s*24\b/.test(text)) {
    fail(`${rel} sets temperature: 24 in source code`);
  }
}

// 8) Secrets must remain ignored and examples must stay empty.
requireIncludes(".gitignore", [".env", ".env.*", "!.env.example"]);
const envExample = read(".env.example");
for (const line of envExample.split(/\r?\n/)) {
  if (!line || line.startsWith("#")) continue;
  const [, value = ""] = line.split("=");
  if (value.trim()) fail(".env.example must not contain real values");
}

if (failures.length > 0) {
  console.error("\nCodex guard failed:\n");
  for (const message of failures) console.error(`- ${message}`);
  process.exit(1);
}

console.log("Codex guard passed.");
